﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CS.ApplicationService.Gateway;
using Sysnify.Infrastructure.Crosscutting.Logging;

namespace CS.ApplicationService.EventHandler
{
    public class ApplicationEvent
    {
        private static volatile ApplicationEvent _instance;
        private static object syncRoot = new Object();

        private ApplicationEvent() { }

        static ApplicationEvent()
        {
            LoadSubscribers();
        }

        public static ApplicationEvent Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (syncRoot)
                    {
                        if (_instance == null)
                            _instance = new ApplicationEvent();
                    }
                }

                return _instance;
            }
        }

        #region User Updated Event
        public event EventHandler<UserUpdateEventArgs> UserUpdated;
        public virtual void RaiseUserUpdatedEvent(UserUpdateEventArgs e)
        {
            EventHandler<UserUpdateEventArgs> handler = UserUpdated;
            if (handler != null)
            {
                var eventListeners = handler.GetInvocationList();
                for (var i = 0; i < eventListeners.Count(); i++)
                {
                    var methodToInvoke = (EventHandler<UserUpdateEventArgs>)eventListeners[i];
                    methodToInvoke.BeginInvoke(this, e, EndAsyncUpdateUserEvent, null);
                }
            }
        }

        private void EndAsyncUpdateUserEvent(IAsyncResult iar)
        {
            var ar = (System.Runtime.Remoting.Messaging.AsyncResult)iar;
            var invokedMethod = (EventHandler<UserUpdateEventArgs>)ar.AsyncDelegate;

            try
            {
                invokedMethod.EndInvoke(iar);
            }
            catch (Exception ex)
            {
                LoggerGateway.Gateway.LogInfo(ex.ToString());
            }
        }
        #endregion

        #region User Created Event
        public event EventHandler<UserCreatedEventArgs> UserCreated;
        public virtual void RaiseUserCreatedEvent(UserCreatedEventArgs e)
        {
            EventHandler<UserCreatedEventArgs> handler = UserCreated;
            if (handler != null)
            {
                var eventListeners = handler.GetInvocationList();
                for (var i = 0; i < eventListeners.Count(); i++)
                {
                    var methodToInvoke = (EventHandler<UserCreatedEventArgs>)eventListeners[i];
                    methodToInvoke.BeginInvoke(this, e, EndAsyncUserCreatedEvent, null);
                }
            }
        }

        private void EndAsyncUserCreatedEvent(IAsyncResult iar)
        {
            var ar = (System.Runtime.Remoting.Messaging.AsyncResult)iar;
            var invokedMethod = (EventHandler<UserCreatedEventArgs>)ar.AsyncDelegate;

            try
            {
                invokedMethod.EndInvoke(iar);
            }
            catch (Exception ex)
            {
                LoggerGateway.Gateway.LogInfo(ex.ToString());
            }
        }
        #endregion

        #region User Profile Communication Changed Event
        public event EventHandler<UserProfileComChangedEventArgs> UserProfileComChanged;
        public virtual void RaiseUserProfileComChangedEvent(UserProfileComChangedEventArgs e)
        {
            EventHandler<UserProfileComChangedEventArgs> handler = UserProfileComChanged;
            if (handler != null)
            {
                var eventListeners = handler.GetInvocationList();
                for (var i = 0; i < eventListeners.Count(); i++)
                {
                    var methodToInvoke = (EventHandler<UserProfileComChangedEventArgs>)eventListeners[i];
                    methodToInvoke.BeginInvoke(this, e, EndAsyncUserProfileComChangedEvent, null);
                }
            }
        }

        private void EndAsyncUserProfileComChangedEvent(IAsyncResult iar)
        {
            var ar = (System.Runtime.Remoting.Messaging.AsyncResult)iar;
            var invokedMethod = (EventHandler<UserProfileComChangedEventArgs>)ar.AsyncDelegate;

            try
            {
                invokedMethod.EndInvoke(iar);
            }
            catch (Exception ex)
            {
                LoggerGateway.Gateway.LogInfo(ex.ToString());
            }
        }
        #endregion

        #region User information from external change event
        public event EventHandler<UserExternalSourceChangedEventArgs> UserExternalSourceChanged;
        public virtual void RaiseUserExternalSourceChangedEvent(UserExternalSourceChangedEventArgs e)
        {
            EventHandler<UserExternalSourceChangedEventArgs> handler = UserExternalSourceChanged;
            if (handler != null)
            {
                var eventListeners = handler.GetInvocationList();
                for (var i = 0; i < eventListeners.Count(); i++)
                {
                    var methodToInvoke = (EventHandler<UserExternalSourceChangedEventArgs>)eventListeners[i];
                    methodToInvoke.BeginInvoke(this, e, EndAsyncUserExternalSourceChangedEvent, null);
                }
            }
        }

        private void EndAsyncUserExternalSourceChangedEvent(IAsyncResult iar)
        {
            var ar = (System.Runtime.Remoting.Messaging.AsyncResult)iar;
            var invokedMethod = (EventHandler<UserExternalSourceChangedEventArgs>)ar.AsyncDelegate;

            try
            {
                invokedMethod.EndInvoke(iar);
            }
            catch (Exception ex)
            {
                LoggerGateway.Gateway.LogInfo(ex.ToString());
            }
        }
        #endregion

        #region Relink Loyalty Card Event
        public event EventHandler<LoyaltyEventRelinkedArgs> LoyaltyCardRelinked;
        public virtual void RaiseLoyaltyCardRelinkedEvent(LoyaltyEventRelinkedArgs e)
        {
            EventHandler<LoyaltyEventRelinkedArgs> handler = LoyaltyCardRelinked;
            if (handler != null)
            {
                var eventListeners = handler.GetInvocationList();
                for (var i = 0; i < eventListeners.Count(); i++)
                {
                    var methodToInvoke = (EventHandler<LoyaltyEventRelinkedArgs>)eventListeners[i];
                    methodToInvoke.BeginInvoke(this, e, EndAsyncLoyaltyCardRelinkedEvent, null);
                }
            }
        }

        private void EndAsyncLoyaltyCardRelinkedEvent(IAsyncResult iar)
        {
            var ar = (System.Runtime.Remoting.Messaging.AsyncResult)iar;
            var invokedMethod = (EventHandler<LoyaltyEventRelinkedArgs>)ar.AsyncDelegate;

            try
            {
                invokedMethod.EndInvoke(iar);
            }
            catch (Exception ex)
            {
                LoggerGateway.Gateway.LogInfo(ex.ToString());
            }
        }
        #endregion

        #region Enroll Loyalty Card Event
        public event EventHandler<LoyaltyEnrolledEventArgs> LoyaltyEnrolled;
        public virtual void RaiseLoyaltyEnrolledEvent(LoyaltyEnrolledEventArgs e)
        {
            EventHandler<LoyaltyEnrolledEventArgs> handler = LoyaltyEnrolled;
            if (handler != null)
            {
                var eventListeners = handler.GetInvocationList();
                for (var i = 0; i < eventListeners.Count(); i++)
                {
                    var methodToInvoke = (EventHandler<LoyaltyEnrolledEventArgs>)eventListeners[i];
                    methodToInvoke.BeginInvoke(this, e, EndAsyncLoyaltyEnrolledEvent, null);
                }
            }
        }

        private void EndAsyncLoyaltyEnrolledEvent(IAsyncResult iar)
        {
            var ar = (System.Runtime.Remoting.Messaging.AsyncResult)iar;
            var invokedMethod = (EventHandler<LoyaltyEnrolledEventArgs>)ar.AsyncDelegate;

            try
            {
                invokedMethod.EndInvoke(iar);
            }
            catch (Exception ex)
            {
                LoggerGateway.Gateway.LogInfo(ex.ToString());
            }
        }
        #endregion



        private static void LoadSubscribers()
        {
            //IEnumerable<ISubscriber> _subscriberList = ComposeSubscribers();
            if (AppServiceGateway.Current != null)
            {
                IEnumerable<ISubscriber> _subscriberList = AppServiceGateway.Current.EventSubscribers;
                if (_subscriberList != null)
                {
                    foreach (var subscriber in _subscriberList)
                    {
                        subscriber.Subscribe();
                    }
                }
            }
        }

        private static IEnumerable<ISubscriber> ComposeSubscribers()
        {
            var dir = new DirectoryInfo(System.AppDomain.CurrentDomain.BaseDirectory + "\\bin");
            var dlls = dir.GetFileSystemInfos("CS*.dll");

            var catalog = new AggregateCatalog();
            foreach (var fi in dlls)
            {
                try
                {
                    var ac = new AssemblyCatalog(Assembly.LoadFile(fi.FullName));
                    var parts = ac.Parts.ToArray(); // throws ReflectionTypeLoadException for bad assemblies
                    catalog.Catalogs.Add(ac);
                }
                catch (ReflectionTypeLoadException ex)
                {
                    foreach (var loaderExc in ex.LoaderExceptions)
                    {
                        LoggerGateway.Gateway.LogError(loaderExc.ToString());
                    }
                }
            }

            var container = new CompositionContainer(catalog);
            return container.GetExportedValues<ISubscriber>();
        }
    }
}
