﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Reflection;

using CS.ApplicationService.Factory;
using CS.ApplicationService.CircularModule;

using CS.Data.CircularModule.Providers;
using CS.ApplicationService.RecipeModule;
using CS.Data.RecipeModule.Providers;
using CS.IndexSearch;
using CS.ApplicationService.SecurityModule;
using CS.Data.MembershipModule.Providers;
using CS.ApplicationService.LoyaltyModule;
using CS.RetalixWS;
using CS.Data.LoyaltyModule.Providers;
using CS.UnitedAppService;
using CS.ApplicationService.SettingModule;
using CS.Data.SettingModule.Providers;
using CS.ApplicationService.PharmacyModule;
using CS.Data.United.PharmacyModule.Providers;
using CS.ApplicationService.MfrCouponModule;
using CS.ApplicationService.EventHandler;

namespace CS.API
{
    public class DefaultAppServiceFactory : IAppServiceFactory
    {
        #region IAppServiceFactory Members

        public virtual ICircularAppService CreateCircularAppService()
        {
            return new CircularAppService(new SqlBannerRepository(),
                                            new SqlStoreRepository(),
                                            new SqlCircularRepository(),
                                            new SqlBoxRepository(),
                                            new SqlPageVersionRepository(),
                                            new SqlCategoryRepository(),
                                            new SqlShoppingListRepository(),
                                            new SqlShoppingListNoteRepository(),
                                            new SqlRecommendedItemRepository(),
                                            new SqlUserShoppingListRepository());
        }

        public virtual IRecipeAppService CreateRecipeAppService()
        {
            var recipeRepo = new SqlRecipeRepository();
            return new RecipeAppService(recipeRepo, new SolrRecipeIndexSearch(recipeRepo), new SqlRecipeBoxRepository());
        }

        public virtual ISecurityAppService CreateSecurityAppService()
        {
            var userRepository = new SqlUserRepository();
            var userCardRepository = new SqlUserCardRepository();
            return new SecurityAppService(userRepository, new SqlResetPasswordRepository(), new SolrUserIndexSearch(userRepository, userCardRepository), new SqlUserCardRepository());
        }

        public virtual ILoyaltyAppService CreateLoyaltyAppService()
        {
            var cardRangeRepo = new SqlCardRangeRepository();
            var userCardRepo = new SqlUserCardRepository();
            var retalixClient = new RetalixSvcClient();
            
            return new UnitedLoyaltyAppService(retalixClient, 
                                                new UnitedCardGenerator(retalixClient, cardRangeRepo, userCardRepo), 
                                                new SqlSRCouponRepository(), new SqlRedeemHistoryRepository(),
                                                userCardRepo, cardRangeRepo, new SqlCouponLoadHistoryRepository(), 
                                                new SqlStateRepository(), new SqlKidClubCardRepository());
        }

        public virtual ApplicationService.SettingModule.ISettingAppService CreateSettingAppService()
        {
            return new SettingAppService(new SqlSettingRepository());
        }

        public virtual ApplicationService.PharmacyModule.IPharmacyAppService CreatePharmacyAppService()
        {
            return new PharmacyAppService(new PDXPharmacyRepository(), new SqlUserPharmacyRepository());
        }

        public virtual ApplicationService.MfrCouponModule.IMfrDigitalCouponAppService CreateMfrDigitalCouponAppService()
        {
            return null;
        }

        public virtual IEnumerable<ISubscriber> EventSubscribers
        {
            get { return new List<ISubscriber>() { new UnitedLoyaltyEventHandler() }; }
        }

        #endregion
    }
}
