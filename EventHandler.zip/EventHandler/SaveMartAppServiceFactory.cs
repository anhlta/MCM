using System.Collections.Generic;
using CS.ApplicationService.CircularModule;
using CS.ApplicationService.EventHandler;
using CS.ApplicationService.LoyaltyModule;
using CS.ApplicationService.MfrCouponModule;
using CS.ApplicationService.SecurityModule;
using CS.BigYAppService;
using CS.Data.CircularModule.Providers;
using CS.Data.LoyaltyModule.Providers;
using CS.Data.MembershipModule.Providers;
using CS.Data.SaveMart.MfrDigitalCouponModule.Providers;
using CS.IndexSearch;
using CS.SaveMartAppService;

namespace CS.API
{
    public class SaveMartAppServiceFactory : DefaultAppServiceFactory
    {
        public override IMfrDigitalCouponAppService CreateMfrDigitalCouponAppService()
        {
            return new SaveMartMfrDigitalCouponAppService(new InmarMfrDigitalCouponRepository());
        }

        public override ILoyaltyAppService CreateLoyaltyAppService()
        {
            var cardRangeRepo = new SqlCardRangeRepository();
            var userCardRepo = new SqlUserCardRepository();
 
            return new SaveMartLoyaltyAppService(new SaveMartCardGenerator(cardRangeRepo, userCardRepo),
                                                new SqlSRCouponRepository(), new SqlRedeemHistoryRepository(),
                                                userCardRepo, cardRangeRepo, new SqlCouponLoadHistoryRepository(),
                                                new SqlStateRepository(), new SqlKidClubCardRepository());
        }

        public override IEnumerable<ISubscriber> EventSubscribers
        {
            get
            {
                return new List<ISubscriber>(new ISubscriber[] { new SaveMartAppServiceEventHandler() });
            }
        }
    }
}