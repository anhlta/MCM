﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS.ApplicationService.CircularModule.Messages;
using CS.ApplicationService.EventHandler;
using CS.ApplicationService.Gateway;
using CS.ApplicationService.LoyaltyModule.Messages;
using CS.ApplicationService.SettingModule;
using CS.Common;
using CS.Data;
using CS.Data.LoyaltyModule;
using CS.Utility;
using Sysnify.Exceptions;
using Sysnify.Infrastructure.Crosscutting.Caching;
using Sysnify.Infrastructure.Crosscutting.Transformer;
using Sysnify.Utility;

namespace CS.ApplicationService.LoyaltyModule
{
    public abstract class BaseLoyaltyAppService : ILoyaltyAppService
    {
        #region Cache Time Settings

        private const int SINGLE_LOYALTY_COUPON_CACHE_TIME = 120;
        private const int MULTI_LOYALTY_COUPON_CACHE_TIME = 120;

        #endregion

        protected ISRCouponRepository _srCouponRepository;
        protected IRedeemHistoryRepository _redeemHistoryRepository;
        protected IUserCardRepository _userCardRepository;
        protected ICouponLoadHistoryRepository _couponLoadHistoryRepository;
        protected IStateRepository _stateRepository;
        protected IKidClubCardRepository _kidClubCardRepository;

        protected string LoyaltyGuestServiveEmail = ConfigurationManager.AppSettings["LoyaltyGuestServiveEmail"];

        public BaseLoyaltyAppService(ISRCouponRepository srCouponRepository, IRedeemHistoryRepository redeemHistoryRepository,
                                        IUserCardRepository userCardRepository, ICouponLoadHistoryRepository couponLoadHistoryRepository,
                                           IStateRepository stateRepository, IKidClubCardRepository kidClubCardRepository)
        {
            _srCouponRepository = srCouponRepository;
            _redeemHistoryRepository = redeemHistoryRepository;
            _userCardRepository = userCardRepository;
            _couponLoadHistoryRepository = couponLoadHistoryRepository;
            _stateRepository = stateRepository;
            _kidClubCardRepository = kidClubCardRepository;
        }

        #region Transformer

        public static LoyaltyCouponRO GetLoyaltyCouponRO(SRCoupon from)
        {
            if (from == null)
                return null;
            var to = Transformer.TransformObject<SRCoupon, LoyaltyCouponRO>(from);
            if (to != null)
            {
                to.Id = from.CouponID;
                to.Title = from.Description;
                to.Description = from.Comments;
                to.Balance = from.ItemQuantity.HasValue ? from.ItemQuantity.Value : 1.0m;
                to.RedeemCost = from.Redeem;
                to.ExpirationDate = from.AbsoluteExpire;
                to.PreviewId = from.PreviewID ?? 0;
                to.ImageFile = UrlHelper.GetSRCouponImageUrl(from.PreviewID, (int)enumThumbnailSizeType.Medium);

                if (from.Category != null)
                    to.CS_Categories = from.Category.Select(c => c.CS_CategoryId).ToList();
            }
            return to;
        }
        public static ShoppingListItemRO GetCouponShoppingListItemRO(LoyaltyCouponRO coupon, string catagoryName, string username)
        {
            if (coupon == null)
                return null;
            return new ShoppingListItemRO()
                         {
                             CategoryName = catagoryName,
                             ImageURL = coupon.ImageFile,
                             ItemPrice = coupon.TextSaving,
                             ProductDesc = coupon.Description,
                             ProductId = coupon.Id,
                             ProductName = coupon.Title,
                             Quantity = 1,
                             ShoppingListId = 0,
                             UserName = username,
                             VisibleQuantity = coupon.ExpirationDate != null ? coupon.ExpirationDate.Value.ToString() : "",
                             ExpirationDate = coupon.ExpirationDate,
                             ReferenceID = null
                         };
        }

        public static IList<LoyaltyCouponRO> GetLoyaltyCouponListRO(IList<SRCoupon> from)
        {
            IList<LoyaltyCouponRO> to = new List<LoyaltyCouponRO>();
            foreach (var coupon in from)
            {
                var ro = GetLoyaltyCouponRO(coupon);

                if (ro != null)
                    to.Add(ro);
            }

            return to;
        }
        public static IList<ShoppingListItemRO> GetLoyatyCouponShoppingList(List<LoyaltyCouponRO> coupons, IList<CategoryRO> categories, string username)
        {
            IList<ShoppingListItemRO> couponlist = new List<ShoppingListItemRO>();

            if (categories != null)
            {
                foreach (var coupon in coupons)
                {
                    string categoryName = "";
                    if (coupon != null && coupon.CS_Categories != null && coupon.CS_Categories.Any())
                    {
                        CategoryRO category =
                            categories.FirstOrDefault(e => e.CS_CategoryId == coupon.CS_Categories.FirstOrDefault());
                        if (category != null)
                            categoryName = category.CategoryName;
                    }
                    var ro = GetCouponShoppingListItemRO(coupon, categoryName, username);
                    if (ro != null)
                        couponlist.Add(ro);
                }
            }
            return couponlist;
        }
        #endregion

        #region ILoyaltyAppService Members

        public abstract bool CheckCardExist(string cardId);

        public abstract LoyaltyDemographicRO GetCardDemographic(string cardId);

        public abstract string GetNewLoyaltyCard(UserRO user);

        public abstract LoyaltyRewardRO GetCardRewardDetail(string cardId, string username);

        public abstract bool UpdateUserInfoToCardDemographic(UserRO userToCard);


        public abstract bool AddCouponToCard(string cardId, int couponId);

        public virtual bool RequestPhysicalCard(string cardId, int bannerId)
        {
            var userCard = _userCardRepository.GetByCardId(cardId).FirstOrDefault();
            if (userCard == null)
                throw new NotFoundException("Requested card has not been registered");

            //var card = _retalixSvcClient.GetCardDemographic(cardId);
            //if (card == null)
            //    throw new NotFoundException("Requested card could not be found");

            var user = SecurityAppServiceGateway.Gateway.GetUser(userCard.UserName);
            if (user == null)
                throw new NotFoundException("Requested user could not be found");

            Dictionary<string, string> tokens = new Dictionary<string, string>();
            tokens.Add("{AltId}", user.Phone);
            tokens.Add("{FirstName}", user.FirstName);
            tokens.Add("{LastName}", user.LastName);
            tokens.Add("{Address}", user.Address);
            tokens.Add("{City}", user.City);
            tokens.Add("{State}", user.State);
            tokens.Add("{ZipCode}", user.ZipCode);
            tokens.Add("{Username}", user.Email);
            tokens.Add("{UserEmail}", user.UserEmail);
            tokens.Add("{CardId}", cardId);

            if (string.IsNullOrEmpty(LoyaltyGuestServiveEmail))
                throw new RequestNotValidException("Missing Loyalty Guest Servive Email Setting");

            string body = ApplicationSetting.Instance.GetEmailTemplate(enumEMAIL.EMAIL_REQUEST_PHYSICAL_CARD_BODY.ToString());
            string subject = ApplicationSetting.Instance.GetEmailTemplate(enumEMAIL.EMAIL_REQUEST_PHYSICAL_CARD_TITLE.ToString());

            OlcDistributionHelper.SendEmail(LoyaltyGuestServiveEmail, null, null, subject, body, tokens, bannerId, true);

            return true;
        }

        public abstract bool RequestMergeAccounts(string username, string cardIdToMerge, int bannerId, string note);

        public abstract IList<LoyaltyRedeemHistoryRO> GetAccountRedeemHistory(string cardId, int rewardAccountId);

        public abstract IList<CouponLoadHistoryRO> GetCouponLoadHistory(string cardId);

        public virtual IList<LoyaltyCouponRO> GetLoyaltyCouponsByType(string couponType, bool includeExpired)
        {
            return GetLoyaltyCouponsByType(couponType, string.Empty, includeExpired);
        }

        public virtual IList<CategoryRO> GetCagoriesLoyaltyCouponByType(string cpn, string keySearch)
        {
            IList<LoyaltyCouponRO> loyaltyCouponsByType = GetLoyaltyCouponsByType(cpn, false);
            if (loyaltyCouponsByType != null)
            {
                if (!string.IsNullOrEmpty(keySearch))
                {
                    keySearch = keySearch.Trim().ToLower();
                    loyaltyCouponsByType =
                        loyaltyCouponsByType.Where(c => c.Brand.ToLower().Contains(keySearch) ||
                                                        c.Title.ToLower().Contains(keySearch) ||
                                                        c.TextSaving.ToLower().Contains(keySearch)
                            ).ToList();
                }
                List<IList<int>> listCats =
                    loyaltyCouponsByType.Where(e => e.CS_Categories != null).Select(e => e.CS_Categories).ToList();
                var listIds = new List<int>();
                foreach (var item in listCats)
                {
                    listIds.AddRange(item);
                }
                int[] catIds = listIds.Distinct().ToArray();
                return CircularAppServiceGateway.Gateway.GetCategoriesByIds(catIds);
            }
            return null;
        }


        public virtual IList<LoyaltyCouponRO> GetLoyaltyCouponsByType(string couponType, string cardID, bool includeExpired)
        {
            var loyaltyCouponRos = (List<LoyaltyCouponRO>)LoadCouponsByType(couponType, includeExpired);

            if (!string.IsNullOrEmpty(cardID))
            {
                List<CouponLoadHistory> couponLoadHistories = _couponLoadHistoryRepository.GetByCardId(cardID).ToList();

                var listTmp = new List<LoyaltyCouponRO>();
                LoyaltyRewardRO retalixLoyaltyReward = GetCardRewardDetail(cardID, "");
                var retalixDigitalCoupons = new List<LoyaltyCouponRO>();
                if (retalixLoyaltyReward != null)
                {
                    retalixDigitalCoupons = retalixLoyaltyReward.DigitalCoupons;
                }
                if (couponType.Equals("DigitalCoupon", StringComparison.CurrentCultureIgnoreCase))
                {
                    foreach (var loyaltyCouponRo in loyaltyCouponRos)
                    {
                        if (retalixDigitalCoupons.Any(
                                e => e.CouponCode == loyaltyCouponRo.CouponCode &&
                                e.ReferenceID == loyaltyCouponRo.ReferenceID))
                        {
                            loyaltyCouponRo.IsAdded = true;
                        }
                        else
                        {
                            if (couponLoadHistories.Any(
                                    e => e.CouponCode == loyaltyCouponRo.CouponCode &&
                                    e.ReferenceID == loyaltyCouponRo.ReferenceID))
                            {
                                listTmp.Add(loyaltyCouponRo);
                            }
                        }
                    }
                }
                loyaltyCouponRos.RemoveAll(listTmp.Contains);
            }
            return loyaltyCouponRos;
        }

        public virtual bool LinkUserToLoyaltyCard(string username, string cardId, bool checkCardExist = true)
        {
            if (!SecurityAppServiceGateway.Gateway.CheckUserExist(username))
                throw new NotFoundException("Requested user could not be found");

            if (checkCardExist)
            {
                if (!CheckCardExist(cardId))
                    throw new NotFoundException("Requested card could not be found");
            }

            var usernames = GetUserNameAssociatedWithCard(cardId);
            if ((usernames != null) && usernames.Any(u => string.Compare(u, username, true) == 0))
                throw new RequestNotValidException("User already associated with another card");
            _userCardRepository.Add(new UserCard()
            {
                CardID = cardId,
                UserName = username,
                EnrolledDate = DateTime.Now
            });
            _userCardRepository.Commit();
            return true;
        }

        public virtual bool ReLinkUserToLoyaltyCard(string username, string cardId, bool checkCardExist = true)
        {
            var user = SecurityAppServiceGateway.Gateway.GetUser(username);
            if (user == null)
                throw new NotFoundException("Requested user could not be found");

            if (checkCardExist)
            {
                if (!CheckCardExist(cardId))
                    throw new NotFoundException("Requested card could not be found");
            }

            if (_userCardRepository.GetByCardId(cardId).Any(uc => string.Compare(uc.UserName, username, true) != 0))
                throw new RequestNotValidException("Requested card is already linked to other account");

            var eventArg = new LoyaltyEventRelinkedArgs()
            {
                UserId = user.UserID,
                NewCardId = cardId
            };

            var currentLink = _userCardRepository.GetByUsername(username).FirstOrDefault();
            DateTime? enrollDate = DateTime.Now;
            if (currentLink != null)
            {
                eventArg.OldCardId = currentLink.CardID;
                if (string.Compare(currentLink.CardID, cardId, true) == 0)
                    return true;

                enrollDate = currentLink.EnrolledDate;
                _userCardRepository.Delete(currentLink);
                _userCardRepository.Commit();
            }

            _userCardRepository.Add(new UserCard()
            {
                CardID = cardId,
                UserName = username,
                EnrolledDate = enrollDate
            });

            _userCardRepository.Commit();

            SecurityAppServiceGateway.Gateway.IndexUser(user.UserID);

            //Raise event
            ApplicationEvent.Instance.RaiseLoyaltyCardRelinkedEvent(eventArg);

            return true;
        }

        public virtual LoyaltyCouponRO GetLoyaltyCoupon(int couponId)
        {
            string key = CacheGateway.GetObjectKey(LoyaltyCouponRO.CacheObjName, couponId.ToString());
            bool found = false;

            var coupon = CacheGateway.Gateway.Get<LoyaltyCouponRO>(key, out found);
            if (coupon == null)
            {
                coupon = GetLoyaltyCouponRO(_srCouponRepository.Get(couponId));
                if (coupon != null)
                    CacheGateway.Gateway.Insert(key, coupon, TimeSpan.FromMinutes(SINGLE_LOYALTY_COUPON_CACHE_TIME));
            }

            return coupon;
        }

        public IList<LoyaltyCouponRO> GetAllLoyaltyCoupons(bool includeDeleted = false)
        {
            string key = CacheGateway.GetQueryKey(LoyaltyCouponRO.CacheSetName, "GetAllLoyaltyCoupons");
            bool found = false;

            var couponIds = CacheGateway.Gateway.Get<List<int>>(key, out found);
            if (couponIds == null)
            {
                if (includeDeleted)
                    couponIds = _srCouponRepository.GetAll().Select(c => c.CouponID).ToList();
                else
                    couponIds = _srCouponRepository.GetAll().Where(c => (c.IsDeleted != true)).Select(c => c.CouponID).ToList();
                CacheGateway.Gateway.Insert(key, couponIds, TimeSpan.FromMinutes(MULTI_LOYALTY_COUPON_CACHE_TIME));
            }

            return GetLoyaltyCoupons(couponIds.ToArray());
        }

        public virtual string[] GetCardsByUsername(string username)
        {
            return _userCardRepository.GetByUsername(username).Select(uc => uc.CardID).ToArray();
        }

        public virtual string EnrollUserToLoyalty(string username)
        {
            var user = SecurityAppServiceGateway.Gateway.GetUser(username);
            if (user == null)
                throw new NotFoundException("Requested user could not be found");

            if (!user.StoreID.HasValue || (user.StoreID.Value <= 0))
                throw new RequestNotValidException("User doesn't have a valid store");

            if (_userCardRepository.GetByUsername(username).Any())
                throw new RequestNotValidException("User already enrolled to loyalty");

            string cardId = GetNewLoyaltyCard(user);
            if (string.IsNullOrEmpty(cardId))
                throw new UnknownErrorException("An error has occurred while generating new loyalty card");

            if (ReLinkUserToLoyaltyCard(username, cardId, false))
            {
                //Raise event
                ApplicationEvent.Instance.RaiseLoyaltyEnrolledEvent(new LoyaltyEnrolledEventArgs()
                {
                    CardId = cardId,
                    UserId = user.UserID
                });

                return cardId;
            }
            else
                throw new UnknownErrorException("Enrollment could not be completed");
        }

        public abstract IList<TransactionRO> GetCardDetailTransactions(string cardId, DateTime from, DateTime to);

        #endregion

        protected virtual IList<LoyaltyCouponRO> LoadCouponsByType(string couponType, bool includeExpired)
        {
            string key = CacheGateway.GetQueryKey(LoyaltyCouponRO.CacheSetName, "GetLoyaltyCouponsByType", couponType, includeExpired.ToString());
            bool found = false;
            var couponIds = CacheGateway.Gateway.Get<List<int>>(key, out found);
            if (couponIds == null || !couponIds.Any())
            {
                couponIds = _srCouponRepository.GetByType(couponType.ToString(), includeExpired).Select(c => c.CouponID).ToList();
                CacheGateway.Gateway.Insert(key, couponIds, TimeSpan.FromMinutes(MULTI_LOYALTY_COUPON_CACHE_TIME));
            }

            return GetLoyaltyCoupons(couponIds.ToArray()).ToList();
        }

        protected abstract bool ValidateCouponRedemption(string cardId, int accountId, decimal balRequired);

        protected IList<LoyaltyCouponRO> GetLoyaltyCoupons(int[] ids)
        {
            var coupons = new List<LoyaltyCouponRO>();

            List<int> notInCache = new List<int>();

            var keys = ids.Select(id => CacheGateway.GetObjectKey(LoyaltyCouponRO.CacheObjName, id.ToString()));
            var dicItems = CacheGateway.Gateway.GetMulti<LoyaltyCouponRO>(keys);
            coupons.AddRange(dicItems.Values.AsEnumerable());

            notInCache = ids.Where(id => !dicItems.ContainsKey(CacheGateway.GetObjectKey(LoyaltyCouponRO.CacheObjName, id.ToString()))).ToList();


            if (notInCache.Count() > 0)
            {
                var fromDb = GetLoyaltyCouponListRO(_srCouponRepository.GetMany(notInCache.ToArray()).ToList());
                coupons.AddRange(fromDb);

                foreach (var itemToCache in fromDb)
                {
                    string key = CacheGateway.GetObjectKey(LoyaltyCouponRO.CacheObjName, itemToCache.Id.ToString());
                    CacheGateway.Gateway.Insert(key, itemToCache, TimeSpan.FromMinutes(SINGLE_LOYALTY_COUPON_CACHE_TIME));
                }
            }

            ILookup<int, LoyaltyCouponRO> lookup = coupons.ToLookup(i => i.Id);

            return ids.SelectMany(id => lookup[id]).OrderBy(e => e.FieldOrder).ToList();
        }

        protected void AddRedeemHistory(string cardId, string username, string couponCode, string promoId, decimal pointRedeem, DateTime redeemDate)
        {
            _redeemHistoryRepository.Add(new RedeemHistory()
            {
                CardID = cardId,
                Username = username,
                CouponCode = couponCode,
                PromotionID = promoId,
                PointRedeem = pointRedeem,
                RedeemDate = redeemDate,
                IsDeleted = false
            });
            _redeemHistoryRepository.Commit();
        }

        protected void AddCouponLoadHistory(string cardId, string couponCode, string referenceID, DateTime redeemDate)
        {
            _couponLoadHistoryRepository.Add(new CouponLoadHistory()
            {
                CardID = cardId,
                CouponCode = couponCode,
                ReferenceID = referenceID,
                LoadedDate = redeemDate
            });
            _couponLoadHistoryRepository.Commit();
        }


        protected string[] GetUserNameAssociatedWithCard(string cardId)
        {
            return _userCardRepository.GetByCardId(cardId).Select(uc => uc.UserName).ToArray();
        }

        public abstract EnrollClubRO EnrollUserToClub(string username, Dictionary<string, string> Options, string type = "");

        public abstract ClubInfoRO GetClubInformation(string userId, string type);

        public virtual bool UpdateSegment(string cardId, int segmentId, DateTime? startDate, DateTime? endDate)
        {
            throw new NotImplementedException();
        }

        public virtual bool RemoveSegment(string cardId, int segmentId)
        {
            throw new NotImplementedException();
        }

        public virtual bool AdjustRewardBalance(string cardId, int rewardAccountId, decimal points, DateTime? expirationDate, string updatedBy, string extra, int storeNumber)
        {
            var endBal = UpdateRewardAccount(cardId, rewardAccountId, points, expirationDate);

            _redeemHistoryRepository.Add(new RedeemHistory()
            {
                CardID = cardId,
                CouponCode = rewardAccountId.ToString(),
                EndBal = endBal,
                PointRedeem = (-1) * points,
                PromotionID = extra,
                RedeemDate = DateTime.Now,
                Username = updatedBy,
                StoreNumber = storeNumber
            });

            _redeemHistoryRepository.Commit();

            return true;
        }

        protected abstract decimal UpdateRewardAccount(string cardId, int rewardAccountId, decimal points, DateTime? expirationDate);

        public string GetStateCode(string state)
        {

            if (string.IsNullOrEmpty(state))
                return string.Empty;
            IQueryable<States> allState = _stateRepository.GetAll();
            foreach (var item in allState)
            {
                if (item != null &&
                    (item.StateId.Equals(state, StringComparison.OrdinalIgnoreCase)
                        || (item.StateName.Equals(state, StringComparison.OrdinalIgnoreCase))
                    ))
                {
                    return item.StateNumber.ToString();
                }
            }

            return state;
        }

        public abstract IList<ShoppingListItemRO> GetLoyaltyCouponShoppingList(string username);

        public abstract KeywordProgressRO GetStatusOptIn(string userid, string type);

        public abstract IList<string> LookupByPhoneNumber(string phone);


        public abstract IList<string> GetMergedAccounts(string cardId);
    }
}
