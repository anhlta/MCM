<?php

/**
 * Element Defaults: Block Grid
 */

return array(
	'id'    => '',
	'class' => '',
	'style' => '',
	'type'  => 'two-up'
);