<?php

return array(
  'title-default' => __( 'Options', 'cornerstone' ),
  'title-theme'   => __( 'Theme Options', 'cornerstone' ),
);
