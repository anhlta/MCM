<div data-component='global/entry-preloader' class="cs-entry-preloader cs-active">
  <div class="cs-entry-preloader-the-circles">
    <div class="cs-entry-preloader-circle-1"></div>
    <div class="cs-entry-preloader-circle-2"></div>
    <div class="cs-entry-preloader-circle-3"></div>
  </div>
</div>
